/*
 * File:   Principal.c
 * Author: Jos� Javier Estrada
 *
 * Created on January 22, 2020, 7:02 PM
 */

// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSC oscillator: CLKOUT function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF       // Brown Out Reset Selection bits (BOR enabled)
#pragma config IESO = OFF        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = OFF       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF         // Low Voltage Programming Enable bit (RB3/PGM pin has PGM function, low voltage programming enabled)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#define  _XTAL_FREQ 4000000
#include <xc.h>

//Prototipos de funciones
void init(void);
void delay_ms (unsigned int dms);
void button (void);
void Inicio(void);
void Juego (void);

// Variables globales
int contador1 = 0;
int contador2 = 0;

//Funcion Principal
void main(void) {
    init();
    if (PORTDbits.RD0==0){
        __delay_ms(1000);   
        if (PORTDbits.RD0){
            Inicio();
            PORTC = 0;
            PORTEbits.RE0 = 0;
            PORTEbits.RE1 = 0;
            PORTEbits.RE2 = 0;
            Juego();
            __delay_ms(2000);
        }
    }
}

//Funcion de Set Up
void init(void){
    TRISA = 0;
    TRISB = 0;
    TRISC = 0;
    TRISE = 0;
    TRISDbits.TRISD0 = 1;
    TRISDbits.TRISD1 = 1;
    TRISDbits.TRISD2 = 1;
    TRISDbits.TRISD6 = 0;
    TRISDbits.TRISD7 = 0;
    ANSEL = 0;
    ANSELH = 0;
    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
    PORTE = 0;
    PORTDbits.RD6 = 0;
    PORTDbits.RD7 = 0;
}

void Inicio(void){
    PORTC = 0b01101011;
    PORTEbits.RE0 = 1;
    PORTEbits.RE1 = 1;
    PORTEbits.RE2 = 1;
    __delay_ms(1000);
    PORTC = 0b00111011;
    PORTEbits.RE0 = 0;
    PORTEbits.RE1 = 1;
    PORTEbits.RE2 = 1;
    __delay_ms(1000);
    PORTC = 0b01000001;
    PORTEbits.RE0 = 0;
    PORTEbits.RE1 = 0;
    PORTEbits.RE2 = 1;
    __delay_ms(1000);
    PORTC = 0b01110111;
    PORTEbits.RE0 = 1;
    PORTEbits.RE1 = 1;
    PORTEbits.RE2 = 1;
    __delay_ms(1000);
} //Semaforo de inicio

//Funciones
//void tabla (void){
//    switch( contador1 ){
//        case 0:
//            PORTB = 0b00000000;
//            PORTBbits.RB0 = 1;
//            break;
//        case 1 :
//            PORTB = 0b00000000;
//            PORTBbits.RB1 = 1;           
//            break;
//        case 2 :
//            PORTB = 0b00000000;
//            PORTBbits.RB2 = 1;            
//            break;
//        case 3:
//            PORTB = 0b00000000;
//            PORTBbits.RB3 = 1;            
//            break;
//        case 4 :
//            PORTB = 0b00000000;
//            PORTBbits.RB4 = 1;            
//            break;
//        case 5 :
//            PORTB = 0b00000000;
//            PORTBbits.RB5 = 1;            
//            break;
//        case 6:
//            PORTB = 0b00000000;
//            PORTBbits.RB6 = 1;            
//            break;
//        case 7 :
//            PORTB = 0b00000000;
//            PORTBbits.RB7 = 1;            
//            break;
//        case 8:
//            PORTB = 0b11111111;
//            PORTDbits.RD7 = 1; 
//            PORTC = 0b00111011;
//            break;
//
//    }
//} //Puerto B
//
//void tabla2 (void){
//    switch( contador2 ){
//        case 0:
//            PORTA = 0b00000000;
//            PORTAbits.RA0 = 1;
//            break;
//        case 1 :
//            PORTA = 0b00000000;
//            PORTAbits.RA1 = 1;           
//            break;
//        case 2 :
//            PORTA = 0b00000000;
//            PORTAbits.RA2 = 1;            
//            break;
//        case 3:
//            PORTA = 0b00000000;
//            PORTAbits.RA3 = 1;            
//            break;
//        case 4 :
//            PORTA = 0b00000000;
//            PORTAbits.RA4 = 1;            
//            break;
//        case 5 :
//            PORTA = 0b00000000;
//            PORTAbits.RA5 = 1;            
//            break;
//        case 6:
//            PORTA = 0b00000000;
//            PORTAbits.RA6 = 1;            
//            break;
//        case 7 :
//            PORTA = 0b00000000;
//            PORTAbits.RA7 = 1;            
//            break;
//        case 8:
//            PORTA = 0b11111111;
//            PORTDbits.RD6 = 1;
//            PORTC = 0b01000010;
//            break;
//
//    }
//} //Puerto A

void Juego (void){
    PORTAbits.RA0 = 1;
    PORTBbits.RB0 = 1;
    int i = 1;
    while (i = 1){
        if (PORTDbits.RD1==0){
            contador1 =1;
        }
        __delay_ms(70);   
        if (PORTDbits.RD1==1 && contador1==1){
            contador1=0;
            PORTA=PORTA*2;
        }
        if (PORTDbits.RD2==0){
            contador2 = 1;
        }
        __delay_ms(70);   
        if (PORTDbits.RD2==1 && contador2==1){
            contador2=0;
            PORTB=PORTB*2;
        }
        if (PORTB==128){
            PORTC = 0b00111011;
            PORTDbits.RD6=1;
            PORTEbits.RE0 = 0;
            PORTEbits.RE1 = 1;
            PORTEbits.RE2 = 1;
            i = 0;
            break;
        }
        if (PORTA==128){
            PORTC = 0b01000001;
            PORTDbits.RD7=1;
            PORTEbits.RE0 = 0;
            PORTEbits.RE1 = 0;
            PORTEbits.RE2 = 1;
            i = 0;
            break;
        }
    }
 }